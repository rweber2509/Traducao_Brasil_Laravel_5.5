<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Validation Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines contain the default error messages used by
    | the validator class. Some of these rules have multiple versions such
    | as the size rules. Feel free to tweak each of these messages here.
    |
    */

    'accepted'             => 'O valor de :attribute deve ser aceito.',
    'active_url'           => 'O valor de :attribute não é uma URL válida.',
    'after'                => 'O valor de :attribute deve ser uma data posterior a :date.',
    'after_or_equal'       => 'O valor de :attribute deve ser uma data posterior ou igual a :date.',
    'alpha'                => 'O valor de :attribute deve conter apenas letras.',
    'alpha_dash'           => 'O valor de :attribute deve conter apenas letras, números e traços.',
    'alpha_num'            => 'O valor de :attribute deve conter apenas letras e números.',
    'array'                => 'O valor de :attribute deve ser um array.',
    'before'               => 'O valor de :attribute deve ser uma data anterior a :date.',
    'before_or_equal'      => 'O valor de :attribute deve ser uma data anterior ou igual a :date.',
    'between'              => [
        'numeric' => 'O valor de :attribute deve ser entre :min e :max.',
        'file'    => 'O arquivo do campo :attribute deve conter entre :min e :max kilobytes.',
        'string'  => 'O valor de :attribute deve conter entre :min e :max caracteres.',
        'array'   => 'O valor de :attribute deve contem entre :min e :max itens.',
    ],
    'boolean'              => 'O valor de :attribute deve ser true ou false.',
    'confirmed'            => 'O valor de :attribute, a conformação não corresponde.',
    'date'                 => 'O valor de :attribute não é uma data válida.',
    'date_format'          => 'O valor de :attribute não combina com o formato :format.',
    'different'            => 'O valor de :attribute e :other devem ser diferentes.',
    'digits'               => 'O valor de :attribute deve ter :digits dígitos.',
    'digits_between'       => 'O valor de :attribute deve estar entre :min e :max dígitos.',
    'dimensions'           => 'O valor de :attribute tem dimensões inválidas para imagem.',
    'distinct'             => 'O valor de :attribute está duplicado.',
    'email'                => 'O valor de :attribute deve ser um endereço de e-mail válido.',
    'exists'               => 'A seleção de :attribute é inválida.',
    'file'                 => 'O conteúdo de :attribute deve ser um arquivo.',
    'filled'               => 'O valor de :attribute deve ter um valor.',
    'image'                => 'O conteúdo de :attribute deve ser uma imagem.',
    'in'                   => 'A seleção de :attribute é inválida.',
    'in_array'             => 'O valor de :attribute não existe em :other.',
    'integer'              => 'O valor de :attribute deve ser um valor inteiro.',
    'ip'                   => 'O valor de :attribute deve ser um endereço IP válido.',
    'ipv4'                 => 'O valor de :attribute deve ser um endereço IPv4 válido.',
    'ipv6'                 => 'O valor de :attribute deve ser um endereço IPv6 válido.',
    'json'                 => 'O valor de :attribute deve ser uma string JSON válida.',
    'max'                  => [
        'numeric' => 'O valor de :attribute não deve ser maior que :max.',
        'file'    => 'O valor de :attribute não deve ser maior que :max kilobytes.',
        'string'  => 'O valor de :attribute não deve conter mais de :max caracteres.',
        'array'   => 'O valor de :attribute não deve conter mais de :max itens.',
    ],
    'mimes'                => 'O valor de :attribute deve ser um arquivo do tipo: :values.',
    'mimetypes'            => 'O valor de :attribute deve ser um arquivo do tipo: :values.',
    'min'                  => [
        'numeric' => 'O valor de :attribute deve ser pelo menos :min.',
        'file'    => 'O valor de :attribute deve conter pelo menos :min kilobytes.',
        'string'  => 'O valor de :attribute deve conter pelo menos :min caracteres.',
        'array'   => 'O valor de :attribute deve conter pelo menos :min itens.',
    ],
    'not_in'               => 'A seleção de :attribute é inválida.',
    'numeric'              => 'O valor de :attribute deve ser numérico.',
    'present'              => 'O valor de :attribute deve estar presente.',
    'regex'                => 'O formato do valor de :attribute é inválido.',
    'required'             => 'O valor de :attribute é obrigatório.',
    'required_if'          => 'O valor de :attribute é obrigatório se :other é :value.',
    'required_unless'      => 'O valor de :attribute é obrigatório a menos que :other está em :values.',
    'required_with'        => 'O valor de :attribute é obrigatório se os valores :values estão presentes.',
    'required_with_all'    => 'O valor de :attribute é obrigatório se os valores :values estão presentes.',
    'required_without'     => 'O valor de :attribute é obrigatório se os valores :values não estão presentes.',
    'required_without_all' => 'O valor de :attribute é obrigatório se nenhum dos valores :values estão presentes.',
    'same'                 => 'O valor de :attribute e :other devem combinar.',
    'size'                 => [
        'numeric' => 'O calor do campo :attribute deve conter :size.',
        'file'    => 'O arquivo do campo :attribute deve conter :size kilobytes.',
        'string'  => 'O valor do campo :attribute deve conter :size caracteres.',
        'array'   => 'O valor do campo :attribute deve conter :size itens.',
    ],
    'string'               => 'O valor do campo :attribute deve ser uma string.',
    'timezone'             => 'O valor do campo :attribute deve conter uma zona válida.',
    'unique'               => 'O valor do campo :attribute já foi utilizado.',
    'uploaded'             => 'Falha no upload do campo :attribute.',
    'url'                  => 'O campo :attribute contem um formato inválido.',

    /*
    |--------------------------------------------------------------------------
    | Custom Validation Language Lines
    |--------------------------------------------------------------------------
    |
    | Here you may specify custom validation messages for attributes using the
    | convention "attribute.rule" to name the lines. This makes it quick to
    | specify a specific custom language line for a given attribute rule.
    |
    */

    'custom' => [
        'attribute-name' => [
            'rule-name' => 'custom-message',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Custom Validation Attributes
    |--------------------------------------------------------------------------
    |
    | The following language lines are used to swap attribute place-holders
    | with something more reader friendly such as E-Mail Address instead
    | of "email". This simply helps us make messages a little cleaner.
    |
    */

    'attributes' => [],

];
